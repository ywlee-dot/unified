---
name: tucon-validator
description: AI 서비스 출력물 완성도 검증 스킬. 프로젝트 slug를 지정하면 5개 체크리스트(원본 충실도, 환각 여부, 구체성, 논리 정합성, 목적 적합성)로 100점 만점 채점하고 리포트를 생성한다. /tucon-validator project-slug 형태로 실행. AI 서비스 품질 검증, 완성도 테스트, 출력물 채점이 필요할 때 사용.
---

# Tucon Validator

AI 서비스 출력물의 완성도를 5개 체크리스트로 채점하는 품질 검증 도구.

## Usage

```
/tucon-validator <project-slug>
```

## Workflow

### Step 1: 프로젝트 식별 및 타입 분류

1. `backend/app/projects/<slug>/manifest.py`에서 프로젝트 정보 확인
2. `service.py`, `schemas.py`를 읽어 입출력 구조 파악
3. 아래 타입 분류표에서 프로젝트 타입 결정:

| 타입 | 프로젝트 | 특성 |
|---|---|---|
| AI 생성(문서) | ai_case_report, data_utilization_report | PDF → AI 보고서 |
| AI 생성(구조화) | business_rule_gen, dataset_summary, open_data_analyzer, evaluation_rag | 구조화 입력 → 구조화 출력 |
| AI 검색/필터 | best_practice_search | 검색 → AI 판별 |
| 규칙 기반 | bid_monitor, gov_news_crawler | 규칙 매칭, AI 미사용 |

### Step 2: 입출력 데이터 확보

**Standard 프로젝트** (evaluation_rag, dataset_summary, open_data_analyzer, gov_news_crawler, bid_monitor):
- `service.py`의 핵심 함수를 추적하여 최근 실행의 입력/출력 데이터 확보
- DB 테이블에서 최근 실행 결과를 조회하거나, 테스트 데이터가 있으면 사용
- mock 모드가 있는 프로젝트는 mock 실행으로 샘플 확보 가능

**n8n 프로젝트** (business_rule_gen, data_utilization_report, ai_case_report 등):
- `n8n_executions` 테이블에서 `result_data` 확인
- 콜백으로 저장된 결과 파일이 있으면 사용
- 없으면 사용자에게 입력 파일과 출력 파일 경로를 요청

입출력이 확보되면 텍스트로 변환:
- Excel: openpyxl로 셀 내용 추출
- PDF: PyPDF2 또는 pdfplumber로 텍스트 추출
- HTML: BeautifulSoup으로 텍스트 추출
- JSON: json.dumps로 직렬화

### Step 3: 규칙 기반 채점 (3개 항목)

`scripts/run_scoring.py`를 실행하여 원본 충실도, 환각 여부, 구체성을 자동 채점:

```bash
python3 <skill-path>/scripts/run_scoring.py \
  --input-file /tmp/tucon_input.txt \
  --output-file /tmp/tucon_output.txt \
  --project-type "ai_generation_document"
```

스크립트가 JSON으로 3개 항목의 원점수를 반환함.

### Step 4: LLM 기반 채점 (2개 항목)

Claude가 직접 아래 2개 항목을 채점. `references/scoring_methodology.md`의 상세 기준을 참조.

#### 4-1. 논리 정합성 (0-15점)

입력과 출력을 읽고 아래 기준으로 채점:
- 15점: 모든 항목 간 인과관계 성립, 모순 없음
- 12점: 사소한 불일치 1건
- 9점: 논리 오류 1건 (결과 해석에 혼란)
- 6점: 논리 오류 2건 또는 조건-결론 모순 1건
- 3점: 심각한 논리 오류 (결론이 근거와 반대)
- 0점: 항목 간 완전히 무관하거나 자기 모순

프로젝트별 특화 검사:
- business_rule_gen: 규칙 조건과 SQL WHERE 절 일치 여부
- ai_case_report: 도입 배경 → 활용 내용 → 기대효과 인과 흐름
- evaluation_rag: 감점 사유와 실제 점수 일치, 개선사항이 감점 항목에 대응
- open_data_analyzer: 1단계→5단계 결론 일관성
- dataset_summary: 키워드와 설명문 내용 일치

#### 4-2. 목적 적합성 (0-15점)

형식 검증 (0-7.5점): 프로젝트별 출력 양식 체크리스트를 `references/scoring_methodology.md`의 "프로젝트별 형식 규칙"에서 확인하고 자동 검증.

내용 적합성 (0-7.5점): 해당 프로젝트의 목적/작성 규칙을 준수하는지 Claude가 판단.

### Step 5: 가중치 적용 및 총점 산출

`references/scoring_methodology.md`의 가중치 매트릭스를 적용:

```
총점 = Σ (항목별 원점수 / 항목 만점 × 타입별 가중치)
```

규칙 기반 프로젝트(bid_monitor, gov_news_crawler)는 원본 충실도 + 환각 여부를 N/A 처리하고 남은 항목으로 100점 재환산.

### Step 6: 등급 판정 및 리포트 생성

**필수 게이트 (하나라도 미달이면 무조건 불합격):**
- AI 타입: 환각 1건 이상이면 불합격
- 전체: 출력 형식 파싱 실패이면 불합격
- 전체: 5개 중 하나라도 해당 항목 만점의 50% 미만이면 불합격

**타입별 통과 기준:**
- AI 생성(문서): 88점
- AI 생성(구조화): 90점
- AI 검색/필터: 85점
- 규칙 기반: 88점

**등급:**

| 등급 | 점수 | 의미 |
|---|---|---|
| S | 95-100 | 프로덕션 배포 가능 |
| A | 통과기준-94 | 통과, 마이너 개선 권장 |
| B | 통과기준-10 ~ 통과기준-1 | 거의 통과, 집중 튜닝 |
| C | 통과기준-20 ~ 통과기준-11 | 미달, 주요 이슈 3개+ |
| D | 통과기준-30 ~ 통과기준-21 | 심각 미달 |
| F | 그 미만 | 근본적 재설계 필요 |

### Step 7: 리포트 출력

아래 형식으로 리포트를 출력하고, `backend/app/projects/<slug>/` 하위에 `quality_report_{timestamp}.json`으로 저장:

```markdown
## 🔍 Tucon Validator Report — {project_name}

| 항목 | 원점수 | 가중 점수 | 상세 |
|---|---|---|---|
| 원본 충실도 | {raw}/25 | {weighted} | 포함률 {n}%, 누락: {list} |
| 환각 여부 | {raw}/25 | {weighted} | 환각 {n}건: {list} |
| 구체성 | {raw}/20 | {weighted} | 일반론 {n}개, 밀도 {n}% |
| 논리 정합성 | {raw}/15 | {weighted} | {issues} |
| 목적 적합성 | {raw}/15 | {weighted} | 형식 {n}/7.5, 내용 {n}/7.5 |

**총점: {total}/100 | 등급: {grade} | 판정: {pass/fail}**

### 미달 항목 피드백
{각 미달 항목에 대한 구체적 개선 제안}
```

## Notes

- 규칙 기반 프로젝트(bid_monitor, gov_news_crawler)는 환각/원본충실도 항목이 N/A
- LLM 채점(논리 정합성, 목적 적합성)은 Claude가 직접 수행하므로 외부 API 호출 불필요
- 상세 방법론(가중치, 임계값, 프로젝트별 규칙)은 `references/scoring_methodology.md` 참조
