#!/usr/bin/env python3
"""
Tucon Validator — 규칙 기반 자동 채점 스크립트

3개 항목(원본 충실도, 환각 여부, 구체성)을 자동 채점합니다.
논리 정합성과 목적 적합성은 LLM(Claude)이 직접 채점합니다.

Usage:
    python3 run_scoring.py --input-file input.txt --output-file output.txt --project-type ai_generation_document
    python3 run_scoring.py --input-text "입력 텍스트" --output-text "출력 텍스트" --project-type ai_generation_structured

Project types:
    ai_generation_document   — AI 생성(문서): ai_case_report, data_utilization_report
    ai_generation_structured — AI 생성(구조화): business_rule_gen, dataset_summary, open_data_analyzer, evaluation_rag
    ai_search_filter         — AI 검색/필터: best_practice_search
    rule_based               — 규칙 기반: bid_monitor, gov_news_crawler
"""

import argparse
import json
import re
import sys
from collections import Counter


# ──────────────────────────────────────────────
# 토큰 추출기
# ──────────────────────────────────────────────

def extract_key_tokens(text: str) -> dict:
    """입력 텍스트에서 핵심 토큰(고유명사, 수치, 날짜, 키워드)을 추출"""
    tokens = {
        "proper_nouns": [],
        "numbers": [],
        "dates": [],
        "keywords": [],
    }

    # 수치 추출: 숫자 + 단위
    number_patterns = re.findall(
        r'(\d[\d,\.]*)\s*(건|명|원|개|%|점|회|년|월|일|억|만|천|백|개소|기관|곳|페이지|자|byte|GB|MB|KB)?',
        text
    )
    for num, unit in number_patterns:
        clean_num = num.replace(',', '')
        if len(clean_num) >= 1:
            tokens["numbers"].append(f"{num}{unit}" if unit else num)

    # 날짜 추출
    date_patterns = [
        r'\d{4}[-./]\d{1,2}[-./]\d{1,2}',          # 2024-01-01
        r'\d{4}년\s*\d{1,2}월(?:\s*\d{1,2}일)?',    # 2024년 1월 15일
        r'\d{4}\.\s*\d{1,2}\.\s*\d{1,2}\.?',        # 2024. 1. 15.
    ]
    for pattern in date_patterns:
        tokens["dates"].extend(re.findall(pattern, text))

    # 고유명사 추출: 한글 기관명 패턴
    org_patterns = [
        r'(?:한국|대한|국립|서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)'
        r'[가-힣]{2,15}(?:공단|공사|원|부|처|청|위원회|센터|진흥원|재단|연구원|연구소|협회|학회)',
        r'[가-힣]{2,8}(?:공단|공사|공사|원|부|처|청|위원회|센터|진흥원|재단|연구원|연구소)',
    ]
    for pattern in org_patterns:
        tokens["proper_nouns"].extend(re.findall(pattern, text))

    # 영문 고유명사 (대문자로 시작하는 2+ 단어 연속, 또는 약어)
    tokens["proper_nouns"].extend(re.findall(r'\b[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)+\b', text))
    tokens["proper_nouns"].extend(re.findall(r'\b[A-Z]{2,10}\b', text))

    # 시스템명/프로젝트명 패턴 (영문+숫자 조합)
    tokens["proper_nouns"].extend(re.findall(r'\b[A-Za-z][\w-]{2,}(?:시스템|플랫폼|서비스|포털)\b', text))

    # 한글 키워드: 3글자 이상 명사 빈도 상위
    nouns = re.findall(r'[가-힣]{3,10}', text)
    noun_counts = Counter(nouns)
    # 상위 20개 (일반 용어 제외)
    stopwords = {'있습니다', '됩니다', '합니다', '입니다', '것입니다', '하였습', '대하여', '대해서',
                 '통하여', '위하여', '따라서', '그리고', '또는', '및', '등', '이상', '이하',
                 '해당', '관련', '사항', '내용', '결과', '현황', '추진', '운영', '관리'}
    tokens["keywords"] = [
        word for word, _ in noun_counts.most_common(30)
        if word not in stopwords
    ][:20]

    # 중복 제거 (날짜는 정규화 후 중복 제거)
    tokens["proper_nouns"] = list(set(tokens["proper_nouns"]))
    tokens["numbers"] = list(set(tokens["numbers"]))
    # 날짜: 숫자 구성이 같으면 중복으로 간주
    seen_date_keys = set()
    unique_dates = []
    for d in tokens["dates"]:
        key = tuple(sorted(re.findall(r'\d+', d)))
        if key not in seen_date_keys:
            seen_date_keys.add(key)
            unique_dates.append(d)
    tokens["dates"] = unique_dates

    return tokens


# ──────────────────────────────────────────────
# 1. 원본 충실도 (Source Fidelity) — 25점 만점
# ──────────────────────────────────────────────

def _extract_date_components(date_str: str) -> set:
    """날짜 문자열에서 연/월/일 숫자를 추출 (형식 무관 매칭용)"""
    nums = re.findall(r'\d+', date_str)
    return set(nums)


def _fuzzy_token_match(token: str, output_text: str) -> bool:
    """토큰이 출력에 존재하는지 유연하게 확인 (공백/구두점/형식 차이 허용)"""
    output_clean = re.sub(r'[\s,.\-~]', '', output_text.lower())
    token_clean = re.sub(r'[\s,.\-~]', '', token.lower())

    # 직접 매칭
    if token_clean in output_clean:
        return True

    # 숫자만 추출하여 매칭 (날짜/수치 형식 차이 허용)
    token_nums = re.findall(r'\d+', token)
    if token_nums:
        # 선행 0 제거 (03 → 3, 01 → 1)
        normalized = [str(int(n)) for n in token_nums]
        # 핵심 숫자(값 >= 3)가 모두 출력에 있으면 매칭
        significant = [n for n in normalized if int(n) >= 3]
        if significant and all(n in output_text for n in significant):
            return True

    return False


def score_fidelity(input_text: str, output_text: str) -> dict:
    """입력의 핵심 토큰이 출력에 포함된 비율을 측정"""
    tokens = extract_key_tokens(input_text)

    all_tokens = []
    found_tokens = []
    missing_tokens = []

    # 카테고리별로 분리 추적 (auto_fail 판정용)
    number_found = 0
    number_total = 0

    for category in ["proper_nouns", "numbers", "dates"]:
        for token in tokens[category]:
            all_tokens.append(token)
            if _fuzzy_token_match(token, output_text):
                found_tokens.append(token)
                if category == "numbers":
                    number_found += 1
            else:
                missing_tokens.append(token)
            if category == "numbers":
                number_total += 1

    # 키워드는 별도 가중치 (0.5)
    keyword_total = 0
    keyword_found = 0
    for kw in tokens["keywords"][:10]:
        keyword_total += 1
        if kw in output_text:
            keyword_found += 1

    # 종합 포함률
    total_count = len(all_tokens) + keyword_total * 0.5
    found_count = len(found_tokens) + keyword_found * 0.5

    if total_count == 0:
        inclusion_rate = 100.0
    else:
        inclusion_rate = (found_count / total_count) * 100

    # 포함률 → 점수 변환
    if inclusion_rate >= 90:
        raw_score = 25
    elif inclusion_rate >= 80:
        raw_score = 20
    elif inclusion_rate >= 70:
        raw_score = 15
    elif inclusion_rate >= 60:
        raw_score = 10
    elif inclusion_rate >= 50:
        raw_score = 5
    else:
        raw_score = 0

    # 0점 자동 실패 조건
    auto_fail = False
    fail_reason = None

    # 기관명이 하나도 없으면 자동 실패
    org_tokens = [t for t in tokens["proper_nouns"]
                  if any(suffix in t for suffix in ['공단', '공사', '원', '부', '처', '청', '센터', '재단'])]
    if org_tokens:
        org_found = any(
            re.sub(r'[\s]', '', t) in re.sub(r'[\s]', '', output_text)
            for t in org_tokens
        )
        if not org_found:
            auto_fail = True
            fail_reason = f"입력의 기관명({org_tokens[:3]})이 출력에 없음"
            raw_score = 0

    # 수치 50% 이상 누락 체크 (numbers 카테고리만, dates 제외)
    if number_total > 0:
        number_missing = number_total - number_found
        if number_missing > number_total * 0.5:
            auto_fail = True
            fail_reason = f"수치 {number_missing}/{number_total}건 누락 (50% 초과)"
            raw_score = 0

    return {
        "item": "원본 충실도",
        "max_score": 25,
        "raw_score": raw_score,
        "inclusion_rate": round(inclusion_rate, 1),
        "total_tokens": len(all_tokens),
        "found_tokens": len(found_tokens),
        "missing_tokens": missing_tokens[:10],
        "auto_fail": auto_fail,
        "fail_reason": fail_reason,
    }


# ──────────────────────────────────────────────
# 2. 환각 여부 (Hallucination Detection) — 25점 만점
# ──────────────────────────────────────────────

WHITELIST = {
    '대한민국', '한국', '공공데이터', '인공지능', 'AI', '빅데이터', '디지털', '클라우드',
    '행정안전부', '과학기술정보통신부', '국무조정실', '기획재정부', '국회',
    '데이터', '시스템', '플랫폼', '서비스', '포털', '네트워크',
    '건', '명', '원', '개', '점', '회', '억', '만', '천',
}


def score_hallucination(input_text: str, output_text: str) -> dict:
    """출력에서 입력에 없는 사실 주장(고유명사/수치)을 감지"""
    output_tokens = extract_key_tokens(output_text)
    input_lower = input_text.lower()
    input_clean = re.sub(r'[\s,.]', '', input_lower)

    hallucinations = []

    # 고유명사 역추적
    for token in output_tokens["proper_nouns"]:
        if token in WHITELIST:
            continue
        clean_token = re.sub(r'[\s,.]', '', token.lower())
        if len(clean_token) < 2:
            continue
        if clean_token not in input_clean:
            hallucinations.append({"type": "proper_noun", "value": token})

    # 수치 역추적 (3자리 이상 숫자만 검사 — 1, 2 같은 단순 숫자는 제외)
    for token in output_tokens["numbers"]:
        num_only = re.sub(r'[^\d]', '', token)
        if len(num_only) < 3:
            continue
        if num_only not in re.sub(r'[^\d\s]', '', input_text):
            # 근사치 확인 (±10%)
            try:
                num_val = int(num_only)
                found_approx = False
                for input_num in re.findall(r'\d{3,}', input_text):
                    input_val = int(input_num)
                    if input_val > 0 and abs(num_val - input_val) / input_val < 0.1:
                        found_approx = True
                        break
                if not found_approx:
                    hallucinations.append({"type": "number", "value": token})
            except ValueError:
                pass

    hallucination_count = len(hallucinations)

    # 환각 건수 → 점수 변환
    score_map = {0: 25, 1: 20, 2: 15, 3: 10, 4: 5}
    raw_score = score_map.get(hallucination_count, 0)

    # 0점 자동 실패 조건
    auto_fail = False
    fail_reason = None

    if hallucination_count >= 5:
        auto_fail = True
        fail_reason = f"환각 {hallucination_count}건 (5건 이상)"

    # 환각 비율 30% 이상 체크
    total_claims = len(output_tokens["proper_nouns"]) + len(output_tokens["numbers"])
    if total_claims > 0 and hallucination_count / total_claims >= 0.3:
        auto_fail = True
        fail_reason = f"환각 비율 {hallucination_count}/{total_claims} = {hallucination_count/total_claims*100:.0f}% (30% 이상)"
        raw_score = 0

    return {
        "item": "환각 여부",
        "max_score": 25,
        "raw_score": raw_score,
        "hallucination_count": hallucination_count,
        "hallucinations": hallucinations[:10],
        "auto_fail": auto_fail,
        "fail_reason": fail_reason,
    }


# ──────────────────────────────────────────────
# 3. 구체성 (Specificity) — 20점 만점
# ──────────────────────────────────────────────

GENERIC_PHRASES = [
    '효율적인 업무 처리', '데이터 기반 의사결정', '투명한 행정', '시민 편의 증진',
    '디지털 전환', '스마트 행정', '업무 효율성 향상', '선진화된 시스템',
    '혁신적인 서비스', '국민 중심', '지속 가능한 발전', '체계적인 관리',
    '합리적인 운영', '효과적인 활용', '적극적인 추진',
]

GENERIC_PATTERNS = [
    r'할\s*것으로\s*기대됨',
    r'할\s*것으로\s*예상됨',
    r'할\s*것으로\s*전망됨',
    r'에\s*기여할\s*것으로',
    r'을\s*도모할\s*수\s*있을\s*것으로',
    r'향상[이될시]?\s*(?:기대|예상|전망)',
    r'개선[이될시]?\s*(?:기대|예상|전망)',
]


def score_specificity(output_text: str) -> dict:
    """출력의 구체성을 측정: 일반론 빈도 + 구체 정보 밀도"""

    # 일반론 구문 감지
    generic_found = []
    for phrase in GENERIC_PHRASES:
        if phrase in output_text:
            generic_found.append(phrase)

    for pattern in GENERIC_PATTERNS:
        matches = re.findall(pattern, output_text)
        generic_found.extend(matches)

    generic_count = len(generic_found)

    # 구체 정보 밀도 계산
    tokens = extract_key_tokens(output_text)
    concrete_count = (
        len(tokens["proper_nouns"]) +
        len(tokens["numbers"]) +
        len(tokens["dates"])
    )

    # 전체 토큰 수 (공백 기준 분리)
    total_words = len(output_text.split())
    if total_words == 0:
        density = 0.0
    else:
        density = (concrete_count / total_words) * 100

    # 점수 변환
    if generic_count <= 1 and density >= 15:
        raw_score = 20
    elif generic_count <= 3 and density >= 10:
        raw_score = 15
    elif generic_count <= 5 and density >= 5:
        raw_score = 10
    elif generic_count >= 6:
        raw_score = 5
    else:
        raw_score = 10  # default mid

    # 전부 일반론이면 0점
    auto_fail = False
    fail_reason = None
    if total_words > 0 and concrete_count == 0 and generic_count >= 3:
        raw_score = 0
        auto_fail = True
        fail_reason = "구체 정보 없이 일반론만으로 구성"

    return {
        "item": "구체성",
        "max_score": 20,
        "raw_score": raw_score,
        "generic_count": generic_count,
        "generic_phrases": generic_found[:10],
        "concrete_density": round(density, 1),
        "concrete_count": concrete_count,
        "total_words": total_words,
        "auto_fail": auto_fail,
        "fail_reason": fail_reason,
    }


# ──────────────────────────────────────────────
# 메인 실행
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='Tucon Validator — 규칙 기반 자동 채점')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--input-file', help='입력 데이터 파일 경로')
    group.add_argument('--input-text', help='입력 데이터 텍스트 (직접 전달)')

    group2 = parser.add_mutually_exclusive_group(required=True)
    group2.add_argument('--output-file', help='출력 데이터 파일 경로')
    group2.add_argument('--output-text', help='출력 데이터 텍스트 (직접 전달)')

    parser.add_argument('--project-type', required=True,
                        choices=['ai_generation_document', 'ai_generation_structured',
                                 'ai_search_filter', 'rule_based'],
                        help='프로젝트 타입')

    args = parser.parse_args()

    # 텍스트 로드
    if args.input_file:
        with open(args.input_file, 'r', encoding='utf-8') as f:
            input_text = f.read()
    else:
        input_text = args.input_text

    if args.output_file:
        with open(args.output_file, 'r', encoding='utf-8') as f:
            output_text = f.read()
    else:
        output_text = args.output_text

    results = {"project_type": args.project_type, "items": []}

    if args.project_type == 'rule_based':
        # 규칙 기반은 충실도/환각 N/A
        results["items"].append({
            "item": "원본 충실도", "max_score": 25, "raw_score": None,
            "status": "N/A", "reason": "규칙 기반 프로젝트 — AI 생성 아님"
        })
        results["items"].append({
            "item": "환각 여부", "max_score": 25, "raw_score": None,
            "status": "N/A", "reason": "규칙 기반 프로젝트 — AI 생성 아님"
        })
    else:
        results["items"].append(score_fidelity(input_text, output_text))
        results["items"].append(score_hallucination(input_text, output_text))

    results["items"].append(score_specificity(output_text))

    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
